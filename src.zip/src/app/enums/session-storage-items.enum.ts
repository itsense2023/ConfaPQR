export enum SessionStorageItems {
  SESSION = '[SESSION]',
  MENU = '[MENU]',
}
