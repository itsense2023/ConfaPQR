export enum RoutesApp {
  LOGIN = 'login',
  REQUEST_MANAGER = 'request-manager',
  LOGOUT = 'logout',
}
