export interface ILogin {
  usuario: string;
  contrasena: string;
  sistema: number;
}
