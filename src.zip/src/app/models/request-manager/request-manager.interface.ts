export interface IRequestManager {
  name: string;
  email: string;
  status: boolean;
}
